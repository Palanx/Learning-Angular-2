

export { ListaItem } from './lista-item.model';
export { Lista } from './lista.model';